from django.contrib import admin

#sjhdkjsahk Register your m

from . models import Cmdr
admin.site.register(Cmdr)

